if (window.location.href.startsWith('https://www.bilibili.com/')) {
  document.addEventListener("mouseover", function (event) {
    var target = event.target;
    if (target.tagName === "A") {
      var link = target.href;
      if (link.includes('BV')) {
        console.log(link);
        chrome.runtime.sendMessage({ action: "getLink", link: link });
      } else {
        console.log("不是BV");
      }
    } else {
      chrome.runtime.sendMessage({ action: "notgetLink" });
    }
  });
}
if (window.location.href.startsWith('https://search.bilibili.com/')) {
  // 添加鼠标移动事件处理程序
  document.addEventListener("mousemove", function (event) {
    // 获取鼠标当前位置的元素
    let targetElement = event.target;

    // 检查是否找到了元素，并且该元素具有指定类名
    if (targetElement && targetElement.classList.contains("bili-video-card__info--tit")) {
      // 获取父元素
      let parentElement = targetElement.parentElement;
      // 声明一个变量，用于存储最近的超链接元素
      let linkElement = null;
      // 在父元素的祖先元素中查找超链接元素
      let ancestorElement = parentElement.closest("a");
      if (ancestorElement) {
        linkElement = ancestorElement.href;
      }
      // 输出结果
      // console.log(targetElement.className);
      console.log(linkElement);
      if (linkElement.includes("BV")) {
      chrome.runtime.sendMessage({ action: "getLink", link: linkElement });
      }
    } else {
      chrome.runtime.sendMessage({ action: "notgetLink" });
    }
  });
}
