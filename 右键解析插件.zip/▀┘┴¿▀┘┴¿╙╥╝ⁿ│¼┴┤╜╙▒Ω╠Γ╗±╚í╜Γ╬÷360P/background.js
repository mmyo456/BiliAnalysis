var link;
function BiliAnalysis(url) {
  console.log(url);
  var BV = /BV[0-9A-Za-z]{0,99}/;
  var P = /(?<=p=).*?(?=&vd)/;
  var BV1 = url.match(BV);
  var P1 = url.match(P);
  console.log(BV1);
  if (BV1 == null) {
    BV1 = url.match(/(?<=bvid=).*?(?=&)/);
  }
  if (P1 == null) {
    P1 = 1;
  }
  var httpRequest = new XMLHttpRequest();
  httpRequest.open('GET', 'https://api.bilibili.com/x/player/pagelist?bvid=' + BV1, true);
  httpRequest.send();
  httpRequest.onreadystatechange = function () {
    if (httpRequest.readyState == 4 && httpRequest.status == 200) {
      var json = JSON.parse(httpRequest.responseText);
      var cid = json.data[P1 - 1].cid;
      var httpRequest1 = new XMLHttpRequest();
      httpRequest1.open('GET', 'https://api.bilibili.com/x/player/playurl?bvid=' + BV1 + '&cid=' + cid + '&qn=16&type=&otype=json&platform=html5&high_quality=1', true);
      httpRequest1.withCredentials = true;
      httpRequest1.send();
      httpRequest1.onreadystatechange = function () {
        if (httpRequest1.readyState == 4 && httpRequest1.status == 200) {
          var json = JSON.parse(httpRequest1.responseText);
          copyToClipboard(json.data.durl[0].url);
          console.log(json.data.durl[0].url);
        }
      };
    }
  };
  showNotification();
}
function showNotification() {
  if (Notification.permission === "granted") {
    var notification = new Notification("解析成功", {
      body: "解析成功",
      icon: "https://i0.hdslb.com/bfs/archive/86848c76a76fe46d84d6ef1ab735d9398ed3ee8e.png"
    });

    notification.onclick = function () {
      // 点击通知后执行的操作
    };
  } else if (Notification.permission !== "denied") {
    Notification.requestPermission().then(function (permission) {
      if (permission === "granted") {
        showNotification();
      }
    });
  }
}
function copyToClipboard(text) {
  var textarea = document.createElement("textarea");
  textarea.value = text;
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand("copy");
  document.body.removeChild(textarea);
  chrome.runtime.onMessage.addListener(messageListener);
  chrome.contextMenus.onClicked.removeListener(menuBiliAnalysis);
}


function menuBiliAnalysis(info, tab) {
  if (info.menuItemId === "myContextMenu") {
    console.log("有链接");
    BiliAnalysis(link);
  }
}
function messageListener(request, sender, sendResponse) {
  if (request.action === "getLink") {
    link = request.link;
    chrome.contextMenus.create({
      id: "myContextMenu",
      title: "复制360P解析地址",
      contexts: ["all"],
    });
    chrome.contextMenus.onClicked.addListener(menuBiliAnalysis);
  } else {
    console.log("没链接删菜单");
    chrome.contextMenus.removeAll();
  }
}
chrome.runtime.onMessage.addListener(messageListener);
