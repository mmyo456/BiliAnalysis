if (window.location.href.startsWith('https://www.bilibili.com') || window.location.href.startsWith("https://space.bilibili.com/")) {
  document.addEventListener("mouseover", function (event) {
    var target = event.target;
    if (target.tagName === "A") {
      var link = target.href;
      if (link.includes('BV')) {
        console.log(link);
        chrome.runtime.sendMessage({ action: "getLink", link: link });
      } else {
        console.log("不是BV");
      }
    } else {
      chrome.runtime.sendMessage({ action: "notgetLink" });
    }
  });
}
if (window.location.href.startsWith('https://search.bilibili.com/')) {
  document.addEventListener("mouseover", function (event) {
    let targetElement = event.target;
    let parentElement;
    let linkElement;
    let ancestorElement;
    if (targetElement && targetElement.classList.contains("bili-video-card__info--tit")) {
      let parentElement = targetElement.parentElement;
      let linkElement = null;
      let ancestorElement = parentElement.closest("a");
      if (ancestorElement) {
        linkElement = ancestorElement.href;
      }
      console.log(linkElement);
      if (linkElement.includes("BV")) {
        chrome.runtime.sendMessage({ action: "getLink", link: linkElement });
      }
    } else {
      chrome.runtime.sendMessage({ action: "notgetLink" });
    }
  });
}
if (window.location.href.startsWith('https://t.bilibili.com/')) {
  document.addEventListener("mouseover", function (event) {
    let targetElement = event.target;
    let parentElement;
    let linkElement;
    let ancestorElement;
    switch (true) {
      case (targetElement && targetElement.classList.contains("bili-dyn-card-video__cover__mask")):
        parentElement = targetElement.parentElement.parentElement.parentElement;
        linkElement = null;
        ancestorElement = parentElement.closest("a");
        if (ancestorElement) {
          linkElement = ancestorElement.href;
        }
        console.log(linkElement);
        if (linkElement.includes("BV")) {
          chrome.runtime.sendMessage({ action: "getLink", link: linkElement });
        } else {
          chrome.runtime.sendMessage({ action: "notgetLink" });
        }
        break;
      case (targetElement && targetElement.classList.contains("bili-dyn-card-video__title")):
        parentElement = targetElement.parentElement.parentElement;
        linkElement = null;
        ancestorElement = parentElement.closest("a");
        if (ancestorElement) {
          linkElement = ancestorElement.href;
        }
        if (linkElement.includes("BV")) {
          chrome.runtime.sendMessage({ action: "getLink", link: linkElement });
        } else {
          chrome.runtime.sendMessage({ action: "notgetLink" });
        }
        break;
      default:
        chrome.runtime.sendMessage({ action: "notgetLink" });
        break;
    }
  });
}

