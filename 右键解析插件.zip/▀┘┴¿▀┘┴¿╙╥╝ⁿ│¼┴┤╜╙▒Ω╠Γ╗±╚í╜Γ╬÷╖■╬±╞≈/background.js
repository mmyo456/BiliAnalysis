var link;

function BiliAnalysis(url) {
  console.log(url);
  copyToClipboard("https://jx.91vrchat.com/bl/?url=" + url);
  showNotification();
}

function showNotification() {
  if (Notification.permission === "granted") {
    var notification = new Notification("解析成功", {
      body: "解析成功",
      icon: "https://i0.hdslb.com/bfs/archive/86848c76a76fe46d84d6ef1ab735d9398ed3ee8e.png"
    });

    notification.onclick = function () {
      // 点击通知后执行的操作
    };
  } else if (Notification.permission !== "denied") {
    Notification.requestPermission().then(function (permission) {
      if (permission === "granted") {
        showNotification();
      }
    });
  }
}

function copyToClipboard(text) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (tabs[0]) {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: (textToCopy) => {
          navigator.clipboard.writeText(textToCopy).catch(err => {
            console.error('剪贴板写入失败:', err);
          });
        },
        args: [text]
      });
    }
  });
}

function menuBiliAnalysis(info, tab) {
  if (info.menuItemId === "myContextMenu") {
    console.log("有链接");
    BiliAnalysis(link);
  }
}

function messageListener(request, sender, sendResponse) {
  if (request.action === "getLink") {
    link = request.link;
    chrome.contextMenus.create({
      id: "myContextMenu",
      title: "复制云端解析地址",
      contexts: ["all"],
    });
    chrome.contextMenus.onClicked.addListener(menuBiliAnalysis);
  } else {
    console.log("没链接删菜单");
    chrome.contextMenus.removeAll();
  }
}

chrome.runtime.onMessage.addListener(messageListener);