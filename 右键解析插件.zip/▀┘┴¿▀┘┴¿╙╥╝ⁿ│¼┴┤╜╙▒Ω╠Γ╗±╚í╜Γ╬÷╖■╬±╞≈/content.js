if (window.location.href.startsWith('https://www.bilibili.com/') || window.location.href.startsWith("https://space.bilibili.com/")) {
  document.addEventListener("mouseover", function (event) {
    var target = event.target;
    if (target.tagName === "A") {
      var link = target.href;
      if (link.includes('BV')) {
        console.log(link);
        try {
          if (chrome.runtime && chrome.runtime.id) {
            chrome.runtime.sendMessage({ action: "getLink", link: link });
          }
        } catch (e) {
          console.log("忽略上下文失效");
        }
      } else {
        console.log("不是BV");
      }
    } else {
      try {
        if (chrome.runtime && chrome.runtime.id) {
          chrome.runtime.sendMessage({ action: "notgetLink" });
        }
      } catch (e) {
        console.log("忽略上下文失效");
      }
    }
  });
}
if (window.location.href.startsWith('https://search.bilibili.com/')) {
  document.addEventListener("mouseover", function (event) {
    let targetElement = event.target;
    let parentElement;
    let linkElement;
    let ancestorElement;
    if (targetElement && targetElement.classList.contains("bili-video-card__info--tit")) {
      let parentElement = targetElement.parentElement;
      let linkElement = null;
      let ancestorElement = parentElement.closest("a");
      if (ancestorElement) {
        linkElement = ancestorElement.href;
      }
      console.log(linkElement);
      if (linkElement.includes("BV")) {
        try {
          if (chrome.runtime && chrome.runtime.id) {
            chrome.runtime.sendMessage({ action: "getLink", link: linkElement });
          }
        } catch (e) {
          console.log("忽略上下文失效");
        }
      }
    } else {
      try {
        if (chrome.runtime && chrome.runtime.id) {
          chrome.runtime.sendMessage({ action: "notgetLink" });
        }
      } catch (e) {
        console.log("忽略上下文失效");
      }
    }
  });
}
if (window.location.href.startsWith('https://t.bilibili.com/')) {
  document.addEventListener("mouseover", function (event) {
    let targetElement = event.target;
    let parentElement;
    let linkElement;
    let ancestorElement;
    switch (true) {
      case (targetElement && targetElement.classList.contains("bili-dyn-card-video__cover__mask")):
        parentElement = targetElement.parentElement.parentElement.parentElement;
        linkElement = null;
        ancestorElement = parentElement.closest("a");
        if (ancestorElement) {
          linkElement = ancestorElement.href;
        }
        console.log(linkElement);
        if (linkElement.includes("BV")) {
          try {
            if (chrome.runtime && chrome.runtime.id) {
              chrome.runtime.sendMessage({ action: "getLink", link: linkElement });
            }
          } catch (e) {
            console.log("忽略上下文失效");
          }
        } else {
          try {
            if (chrome.runtime && chrome.runtime.id) {
              chrome.runtime.sendMessage({ action: "notgetLink" });
            }
          } catch (e) {
            console.log("忽略上下文失效");
          }
        }
        break;
      case (targetElement && targetElement.classList.contains("bili-dyn-card-video__title")):
        parentElement = targetElement.parentElement.parentElement;
        linkElement = null;
        ancestorElement = parentElement.closest("a");
        if (ancestorElement) {
          linkElement = ancestorElement.href;
        }
        if (linkElement.includes("BV")) {
          try {
            if (chrome.runtime && chrome.runtime.id) {
              chrome.runtime.sendMessage({ action: "getLink", link: linkElement });
            }
          } catch (e) {
            console.log("忽略上下文失效");
          }
        } else {
          try {
            if (chrome.runtime && chrome.runtime.id) {
              chrome.runtime.sendMessage({ action: "notgetLink" });
            }
          } catch (e) {
            console.log("忽略上下文失效");
          }
        }
        break;
      default:
        try {
          if (chrome.runtime && chrome.runtime.id) {
            chrome.runtime.sendMessage({ action: "notgetLink" });
          }
        } catch (e) {
          console.log("忽略上下文失效");
        }
        break;
    }
  });
}